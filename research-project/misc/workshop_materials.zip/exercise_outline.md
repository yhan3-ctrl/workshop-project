# Exercise outline

Read the attendance table and distinguish visits from unique participants.
